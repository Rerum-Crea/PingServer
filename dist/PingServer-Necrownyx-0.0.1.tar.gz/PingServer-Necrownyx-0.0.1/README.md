# PingServer
 Python package to make creating a ping server easier
